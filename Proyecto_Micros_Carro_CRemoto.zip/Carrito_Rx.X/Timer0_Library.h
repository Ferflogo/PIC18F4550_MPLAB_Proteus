void Timer0_Init(void);

void __interrupt() ISR_TIMER0(void);
