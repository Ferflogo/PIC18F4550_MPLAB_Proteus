void UART_Init(long BAUD);

char UART_Rx(void); // Recepcion de Datos
