/*
 * File:   Main.c
 * Author: FernandoFG
 *
 * Created on 23 de junio de 2020, 10:15 PM
 */


#include <xc.h>
#include "UART_Rx_Library.h"
#include "Configuration.h"
#include "PWM_Library.h"
#include "Timer0_Library.h"
#include "INT0_Library.h"

#define true 1
#define false 0

char Register;

char Reg_A, Reg_B, Reg_C;
int Duty_Cycle;
int Blink;
int Shutdown;

void Initial(void){
    Shutdown = false;
    TRISD = 0;  // Puerto D como salida
    TRISA = 0;
    UART_Init(9600);
    InitPWM_CCP1();
    Register = 0;
    Reg_A = 0;
    Reg_B = 0;
    Reg_C = 0;
    Duty_Cycle = 0;
    Blink = 0;
    Timer0_Init();
    Int_Init();
}

void main(void) {
    
    Initial();

    while(!Shutdown){
        if(PORTBbits.RB0){
            INTCONbits.INT0IF = 0b1;
        }
        Register = UART_Rx();
        Reg_A = Register&0b11100000;
        Reg_B = Register&0b00011000;
        Reg_C = Register&0b00000110;
        PORTD = Register;
        PWM_Cycle(Duty_Cycle);
        Blink = Blink + 1;
        INTCONbits.TMR0IF = 1;
    }
    PWM_Cycle(0);
    LATAbits.LA0 = 0b1;
    LATAbits.LA1 = 0b1;
    LATAbits.LA2 = 0b1;
    return;
}

void __interrupt() ISR(void){

    if(INTCONbits.TMR0IF){

        if(Reg_A == 0b00000000){            // Velocity 1
            //PWM_Cycle(0);
            Duty_Cycle = 0;
        }else if(Reg_A == 0b00100000){      // Velocity 2
            //PWM_Cycle(0);
            Duty_Cycle = 0x9;
        }else if(Reg_A == 0b01000000){      // Velocity 3
            //PWM_Cycle(0);
            Duty_Cycle = 0x13;
        }else if(Reg_A == 0b01100000){      // Velocity 4
            //PWM_Cycle(0);
            Duty_Cycle = 0x1B;
        }else if(Reg_A == 0b10000000){      // Velocity 5
            //PWM_Cycle(0);
            Duty_Cycle = 0x26;
        }else{
            Duty_Cycle = 0;
        }
        
        if(Reg_B == 0b00000000){            // Direction Center
            LATAbits.LA0 = 0b0;
            LATAbits.LA1 = 0b0;
        }else if(Reg_B == 0b00001000){      // Direction Left
            LATAbits.LA0 = 0b1;
            LATAbits.LA1 = 0b0;
        }else if(Reg_B == 0b00010000){      // Direction Right
            LATAbits.LA0 = 0b0;
            LATAbits.LA1 = 0b1;
        }else{
            LATAbits.LA0 = 0b0;
            LATAbits.LA1 = 0b0;
        }
        
        if(Reg_C == 0b00000000){            // Turn off the Headlight
            LATAbits.LA2 = 0b0;
        }else if(Reg_C == 0b00000010){      // Always on Headlight
            LATAbits.LA2 = 0b1;
        }else if(Reg_C == 0b00000100){      // Blink Headlight
            if(Blink > 900){
                LATAbits.LA2 = ~LATAbits.LA2;
                Blink = 0;
            }
        }else{
            LATAbits.LA2 = 0b0;
        }
        
        INTCONbits.TMR0IF = 0;      // Se baja la Bandera de interrupcion Tmr0
        
    }
    
    if(INTCONbits.INT0IF){
        Shutdown = true;
        LATAbits.LA3 = 0b1;
        INTCONbits.INT0IF = 0;
    }
}
