void InitPWM_CCP1(void);

void PWM_Cycle(int duty_cicle);
