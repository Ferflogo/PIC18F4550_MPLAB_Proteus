/*
 * File:   newmain.c
 * Author: FernandoFG
 *
 * Created on 24 de junio de 2020, 12:57 AM
 */


#include <xc.h>

void main(void) {
    return;
}
