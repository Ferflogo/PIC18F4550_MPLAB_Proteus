/*
 * File:   Timer0_Library.c
 * Author: FernandoFG
 *
 * Created on 23 de junio de 2020, 11:01 PM
 */

#include <xc.h>
#include "Configuration.h"
#include "Timer0_Library.h"

void Timer0_Init(void){
    INTCONbits.GIE = 0;
    T0CONbits.T0CS = 0;     // Temporizador
    T0CONbits.PSA = 0;      // Habilita Preescala
    T0CONbits.T0PS = 0b111; // Preescala de 1:256
    T0CONbits.T08BIT = 0;   // 16 ibts de cuenta
    T0CONbits.TMR0ON = 1;   // Tmr0 Empieza
    INTCONbits.TMR0IF = 0;  // Flag del Tmr0 en Bajo
    INTCONbits.TMR0IE = 1;  // Habilita el Overflow
    INTCONbits.PEIE = 1;    // Habilita interrupciones Perifericas
    INTCONbits.GIE = 1;     // Permite las interrupciones
    // Esto tambien se podria hacer como T0CON = 0b10000111;
}
