/*
 * File:   INT0_Library.c
 * Author: FernandoFG
 *
 * Created on 24 de junio de 2020, 12:56 AM
 */


#include <xc.h>
#include "Configuration.h"
#include "INT0_Library.h"

void Int_Init(void) {
    TRISBbits.RB0 = 1;          // Puerto de Entrada
    INTCONbits.INT0IE = 1;      // Habilita Interrupciones
    INTCONbits.INT0IF = 0;      // Flag de Int0 en 0
    INTCON2bits.INTEDG0 = 1;    // Flanco Ascendente
}
