/*
 * File:   UART_Tx_Library.c
 * Author: FernandoFG
 *
 * Created on 23 de junio de 2020, 08:43 PM
 */

#include <xc.h>
#include "Configuration.h"
#include "UART_Tx_Library.h"

void USART_Init(long BAUD){
    // Configuracion
    TXSTAbits.BRGH = 0;             // Asincrono de baja velocidad
    TXSTAbits.SYNC = 0;             // Asincrono
    RCSTAbits.SPEN = 1;             // Habilita pines como TX y RX 
    
    // Configuracion de los Pines
    TRISCbits.TRISC6 = 0;           // RC6(Salida) => Transmicion
    TRISCbits.TRISC7 = 1;           // RC7(Entrada) => Recepcion
    
    // Baudios
    SPBRG = (unsigned char) (((_XTAL_FREQ/BAUD)/64)-1);
    
    // Transmision
    TXSTAbits.TX9 = 0;              // 8 Bits de Datos
    TXSTAbits.TXEN = 1;             // Habilita de Transmision
    
    // Recepcion
    RCSTAbits.RC9 = 0;              // 8 Bits de Datos
    RCSTAbits.CREN = 1;             // Habilita la Recepcion
}

void USART_Tx(char data){
    TXREG = data;
}