void USART_Init(long BAUD);

void USART_Tx(char data); // Transmicion de Datos
