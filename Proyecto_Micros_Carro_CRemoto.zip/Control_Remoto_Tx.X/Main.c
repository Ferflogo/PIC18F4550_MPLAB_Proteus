/*
 * File:   Main.c
 * Author: FernandoFG
 *
 * Created on 23 de junio de 2020, 08:41 PM
 */


#include <xc.h>
#include "Configuration.h"
#include "ADC_Library.h"
#include "UART_Tx_Library.h"

#define true 1 

char Byte_Control;
char Velocity;
int headlight;

void Initial(void){
    USART_Init(9600);
    LATA = 0;
    Init_ADC();
    Byte_Control = 0b00000000;
    headlight = 0;
}

void main(void) {
    Initial();
    while(true){
        
        Velocity = ADC_Read();
        
        if(Velocity < 0b00000100){
            Byte_Control = Byte_Control&0b00011111;
        }else if(Velocity < 0b10000000){
            Byte_Control = Byte_Control&0b00011111;
            Byte_Control = Byte_Control|0b00100000;
        }else if(Velocity < 0b10110011){
            Byte_Control = Byte_Control&0b00011111;
            Byte_Control = Byte_Control|0b01000000;
        }else if(Velocity < 0b11100110){
            Byte_Control = Byte_Control&0b00011111;
            Byte_Control = Byte_Control|0b01100000;
        }else{
            Byte_Control = Byte_Control&0b00011111;
            Byte_Control = Byte_Control|0b10000000;
        }
        
        if((PORTAbits.RA1 && PORTAbits.RA2) || (!PORTAbits.RA1 && !PORTAbits.RA2)){
            Byte_Control = Byte_Control&0b11100111;
        }else if(PORTAbits.RA1){
            Byte_Control = Byte_Control&0b11100111;
            Byte_Control = Byte_Control|0b00001000;
        }else if(PORTAbits.RA2){
            Byte_Control = Byte_Control&0b11100111;
            Byte_Control = Byte_Control|0b00010000;
        }
        
        if(PORTAbits.RA3){
            __delay_ms(100);
            if(!PORTAbits.RA3 && headlight == 0){
                Byte_Control = Byte_Control&0b11111001;
                headlight = 1;
            }else if(!PORTAbits.RA3 && headlight == 1){
                Byte_Control = Byte_Control&0b11111001;
                Byte_Control = Byte_Control|0b00000010;
                headlight = 2;
            }else if(!PORTAbits.RA3 && headlight == 2){
                Byte_Control = Byte_Control&0b11111001;
                Byte_Control = Byte_Control|0b00000100;
                headlight = 0;
            }else{headlight = 0;}
        }
        
        USART_Tx(Byte_Control);
        __delay_ms(10);  
    }
    return;
}
