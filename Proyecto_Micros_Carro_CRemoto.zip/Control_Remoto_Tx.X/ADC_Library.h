void Init_ADC(void);

char ADC_Read(void);
