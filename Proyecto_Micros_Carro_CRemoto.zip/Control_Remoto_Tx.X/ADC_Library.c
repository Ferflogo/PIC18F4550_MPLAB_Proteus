/*
 * File:   ADC_Library.c
 * Author: FernandoFG
 *
 * Created on 23 de junio de 2020, 08:42 PM
 */

#include "Configuration.h"
#include "ADC_Library.h"

void Init_ADC(void){
    TRISA = 1;              // Puerto A de Entrada
    TRISD = 0;              // Puerto D como Salida
    ADCON1bits.PCFG = 0b1110;    // Solo Puerto RA0 Analogico
    ADCON1bits.VCFG = 0;    // Voltaje de referencia seran Vref+ = Vdd y Vref- = Vss
    ADCON0 = 0;             /* El canal utilizado es el 0000 (AN0)
                             * GO/DONE = 0 -> Estatus de la Conversion
                             *      *Cuando ADON = 1
                             *          Conversion en progreso GO/DONE = 1
                             *          A/D Idle (en espera)   GO/DONE = 0
                             * ADON = 0 -> El modulo esta desabilitado**
                             */
    ADCON2bits.ACQT = 3;    // 16TAD (A/D Acquisition Time Select bits))
    ADCON2bits.ADCS = 5;    // FOSC/16 (A/D Convserion Clock Select bits))
    ADCON2bits.ADFM = 1;    // Justificacion Derecha
}

char Register;

char ADC_Read(void){
    ADCON0bits.ADON = 1;
    ADCON0bits.GO_DONE = 1;             // Se avisa que se esta realizando una conversion
    while(ADCON0bits.GO_DONE == 1);     //Mantiene un bucle mientras se realiza la conversion
    ADCON0bits.ADON = 0;                 // Se deshabilita las conversiones
    Register = (ADRES>>2);
    PORTD = Register;                     // Registro donde se guarda la conversion de el dato
    return Register;
}
